Proyecto Sitio Web Raimundo Correa

Este proyecto es una pagina web tipo blog donde pretendo mostrar todo lo que he aprendido a lo largo del curso desarrollo sitios web, además de mostrar lo que hacia antes de empezar este curso.

El sitio, al ser un blog personal, constara de un solo usuario administrador.

Para convertir el sitio estatico a uno auto administrable desarrollare distintos tipos de entradas, una para mostrar los proyectos web en los cuales he trabajado, otra para mi carrera como sonidista y una tercera para mostrar mi pasión por la música.


Guía de Colores

Aun no logro definir bien el uso de colores que deseo para este proyecto pero igualmente agrege algunos para ir probando. Espero poder llegar a los colores definitivos lo antes posible.

$white: #ffffff;
$black: #000000;
$mangogris: #535c68;
$oscuro: #204051;
$oscuromedio: #3b6978;
$claromedio: #84a9ac;
$claro: #cae8d5;


Tipografías

Las tipografías seran dos, una para los titulos y barra de navegación del sitio, y otro para los textos del sitio web en general.

$roboto: 'Roboto', sans-serif;
$raleway: 'Raleway', sans-serif;
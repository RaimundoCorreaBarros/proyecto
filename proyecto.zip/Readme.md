Proyecto Sitio Web Raimundo Correa

Este proyecto es una pagina web tipo blog donde pretendo mostrar todo lo que he aprendido a lo largo del curso desarrollo sitios web, además de mostrar lo que hacia antes de empezar este curso.

El sitio, al ser un blog personal, constara de un solo usuario administrador.

Para convertir el sitio estatico a uno auto administrable desarrollare distintos tipos de entradas, una para mostrar los proyectos web en los cuales he trabajado, otra para mi carrera como sonidista y una tercera para mostrar mi pasión por la música.


Guía de Colores

En este proyecto use como base el color azul y el blanco para que sea un sitio mas bien limpio. Para los textos use un tono gris para que sea mas suave su lectura. Finalmente defini un color rojizo para el call to action del sitio web.

$white: #ffffff;
$black: #000000;
$mangogris: #535c68;

$oscuro: #204051;
$oscuromedio: #3b6978;
$claromedio: #84a9ac;
$claro: #cae8d5;

$cv1: #ff4f5e;
$cv2: #B32531;


Tipografías

Las tipografías seran dos, una para los titulos y barra de navegación del sitio, y otro para los textos del sitio web en general.

$roboto: 'Roboto', sans-serif;
$raleway: 'Raleway', sans-serif;